# Nature Hotel & Sauna — Panel de Recepción con Asistente AI
## Kit Completo v2.0

---

## 📦 Qué descargaste

```
├── index.html                              ← Panel actualizado con asistente AI
├── server.js                               ← Backend del asistente (Node.js)
├── package.json                            ← Dependencias del backend
├── Manual Panel de Recepcion - Nature Hotel & Sauna.pdf  ← Manual imprimible
├── DEPLOYMENT_GUIDE.md                     ← Cómo deployar el backend
├── ASISTENTE_FEATURES.md                   ← Documento de valor para la gerente
└── Panel Nature Hotel & Sauna.html         ← Versión anterior (ignorar)
```

---

## ⚡ Implementación en 5 pasos

### **Paso 1: Actualizar el panel en cPanel (2 min)**

1. Entra a cPanel → Administrador de archivos
2. Navega a `panel.naturehotel.com.pe`
3. Reemplaza el `index.html` con el nuevo descargado
4. Recarga la página en navegador: **Ctrl+F5**

✓ Verás un botón 🤖 en la esquina inferior derecha

---

### **Paso 2: Crear cuenta en Render.com (3 min)**

1. Ve a [render.com](https://render.com) → Sign up (gratis)
2. Verifica email

---

### **Paso 3: Conseguir API key de Anthropic (1 min)**

1. Ve a [console.anthropic.com](https://console.anthropic.com)
2. **API Keys** → New Key → Copia la clave
3. Guárdala en un lugar seguro

---

### **Paso 4: Deployar el backend en Render (5 min)**

**Opción A: Via GitHub (recomendado)**

```bash
# En tu terminal/Git Bash:
cd Downloads  # o donde hayas descargado los archivos
git init
git add server.js package.json
git commit -m "Nature Hotel asistente"
git remote add origin https://github.com/TU_USUARIO/nature-hotel-asistente.git
git branch -M main
git push -u origin main
```

Luego:
1. En Render.com → **New Web Service** → conecta tu repo GitHub
2. Runtime: Node
3. Build: `npm install`
4. Start: `npm start`
5. **Environment:** Agrega `ANTHROPIC_API_KEY` = tu clave de Anthropic
6. Deploy

Render te dará una URL tipo: `https://nature-hotel-asistente.onrender.com`

**Opción B: Direct Upload (sin GitHub)**
- Render permite subir ZIP directo (más lento, busca en docs)

---

### **Paso 5: Actualizar la URL en el panel (2 min)**

En `index.html` descargado, busca esta línea (alrededor de línea 865):

```javascript
const ENDPOINT_ASISTENTE = 'https://nature-panel-api.onrender.com/chat';
```

Reemplázala con tu URL de Render:

```javascript
const ENDPOINT_ASISTENTE = 'https://nature-hotel-asistente.onrender.com/chat';
```

Guarda, sube a cPanel de nuevo, **Ctrl+F5** en navegador.

---

## 🧪 Verificar que funciona

1. Abre el panel en `panel.naturehotel.com.pe`
2. Haz clic en el botón 🤖 abajo a la derecha
3. Escribe: **"¿Quién está disponible?"**
4. Deberías ver una respuesta inteligente en 1-2 segundos

**Si funciona:** ✅ Listo para presentar a Nature  
**Si no funciona:** Revisa Troubleshooting en DEPLOYMENT_GUIDE.md

---

## 📊 Presentación a la gerente

Usa el documento **ASISTENTE_FEATURES.md** para presentar. Puntos clave:

- **Eficiencia:** Consultas instantáneas vs. búsqueda manual (5+ min)
- **Diferenciación:** Casi ningún spa en Lima tiene IA integrada
- **Costo:** Solo $5-15/mes (menos que un café diario)
- **Escalable:** Base para chatbot público (clientes consultan 24/7)

**Propuesta comercial:**
> *"Implementamos un asistente de IA que entiende tu panel en tiempo real. Recepción hace preguntas naturales ('¿Quién está disponible?') y recibe respuestas instantáneas. Esto reduce errores, acelera ventas y posiciona a Nature Hotel como un spa de tecnología de punta."*

---

## 📋 Checklist de despliegue

- [ ] Descargué los archivos
- [ ] Actualicé `index.html` en cPanel
- [ ] Creé cuenta en Render.com
- [ ] Obtuve API key de Anthropic
- [ ] Deployé `server.js` y `package.json` en Render
- [ ] Actualicé la URL en `index.html`
- [ ] Probé el asistente con una consulta
- [ ] Mostré a la gerente el ASISTENTE_FEATURES.md
- [ ] ¡Demanda el asistente en la presentación!

---

## 🚀 Próximas fases (comercial)

Después de que Nature apruebe esta versión:

**Fase 2 (Upgrade Premium):**
- Historial persistente de consultas (auditoría)
- Integración WhatsApp para clientes
- Dashboard de predictivos de ocupación

**Fase 3 (Full SaaS):**
- Chatbot público en web de Nature
- API para third-party (otras saunas, hoteles)
- Modelo de suscripción mensual

---

## ❓ Troubleshooting rápido

**"El asistente no responde"**
→ Verifica console (F12) para errores  
→ Render puede tardar en iniciar (30 seg en free tier)  
→ Revisa que la URL en `const ENDPOINT_ASISTENTE` sea correcta

**"Error: ANTHROPIC_API_KEY no configurada"**
→ En Render, ve a tu servicio → Environment → verifica que esté  
→ Redeploy manualmente

**"Conexión rechazada"**
→ Backend en Render puede estar durmiendo (free tier)  
→ Cualquier request lo reactiva en 30 seg  
→ Revisa logs en Render dashboard

---

## 📞 Soporte

Cualquier problema o ajustes: contactar a **Roas Seeker**

---

## 📄 Archivos auxiliares

- **Manual Panel de Recepcion...pdf** — Imprime para recepción (6 páginas)
- **DEPLOYMENT_GUIDE.md** — Guía técnica detallada
- **ASISTENTE_FEATURES.md** — Documento de venta para gerencia

---

**Versión:** 2.0 con Asistente AI  
**Desarrollado por:** Roas Seeker  
**Fecha:** Julio 2026  
**Estado:** Listo para producción ✅
